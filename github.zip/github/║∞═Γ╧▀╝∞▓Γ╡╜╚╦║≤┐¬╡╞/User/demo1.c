#include "demo.h"
//#include "./BSP/ATK_MW1278D/atk_mw1278d.h"
//#include "./BSP/ATK_MW1278D/atk_mw1278d.h"

#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/OLED/oled.h"
#include "./BSP/ATK_MW1278D/atk_mw1278d_uart.h"
#include "./BSP/ATK_MW1278D/atk_mw1278d.h"
#include "stm32f1xx_hal.h"

void RedLineGPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitStruct.Pin = GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;   
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; 
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET); 
}

void demo_run1(void)
{
    RedLineGPIO_Init();
	//�����߳�ʼ��
	printf("RedLine init Yes!\r\n");
    atk_mw1278d_uart_rx_restart();
    while (1)
    {
		delay_ms(500);
        uint8_t value;
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET); 
        value = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_6);
        if (value == 0)
        {
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,GPIO_PIN_SET); 
			printf("no person\r\n");
			delay_ms(500);
        }
        else
        {
			if (atk_mw1278d_free() != ATK_MW1278D_EBUSY)
            {
                atk_mw1278d_uart_printf("1\r\n");
				printf("GPIO8 has been high!!\r\n");
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,GPIO_PIN_RESET);
				delay_ms(2000);
				OLED_Clear();
            }		
        }
    }
}
	




