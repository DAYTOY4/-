import sensor
import time
import math
import pyb
pin7 = pyb.Pin('P7', pyb.Pin.OUT)
pin8 = pyb.Pin('P8', pyb.Pin.OUT)
threshold_index = 0
thresholds = [
    (30, 100, 15, 127, 15, 127),
    (30, 100, -64, -8, -32, 32),
    (0, 30, 0, 64, -128, 0),
]
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time=2000)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(True)
clock = time.clock()
while True:
    clock.tick()
    img = sensor.snapshot()
    blobs_detected = False
    for blob in img.find_blobs(
        [thresholds[threshold_index]],
        pixels_threshold=200,
        area_threshold=200,
        merge=True,
    ):
        blobs_detected = True
        img.draw_rectangle(blob.rect())
        img.draw_cross(blob.cx(), blob.cy())
    if blobs_detected:
        pin7.value(1)
        pyb.delay(70)
        pin7.value(0)

        print(blobs_detected)
    else:
        pin8.value(1)
        pyb.delay(70)
        pin8.value(0)

        print(blobs_detected)
