#ifndef _ESP8266_H_
#define _ESP8266_H_

#include "./BSP/esp8266/main.h"


char* Lora_GetMessage(void);
#endif
