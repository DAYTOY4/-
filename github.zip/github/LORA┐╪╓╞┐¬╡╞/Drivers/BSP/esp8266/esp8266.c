#include "stm32f1xx_hal.h"                 // Device header
#include "./BSP/esp8266/esp8266.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "oled.h"
#include "./BSP/esp8266/core_json.h"
#include "./BSP/ATK_MW1278D/atk_mw1278d.h"
#include "./BSP/ATK_MW1278D/atk_mw1278d_uart.h"

/*
*************************************
�궨��
*************************************
*/
#define WIFI_SSID        "ChinaNet-xHGyTu"
#define WIFI_PASSWD      "123456asd."

#define MQTT_CLIENT_ID  "k1amgRdBbwz.mqtt_stm32|securemode=2\\,signmethod=hmacsha256\\,timestamp=1742912515041|"
#define MQTT_USER_NAME  "mqtt_stm32&k1amgRdBbwz"
#define MQTT_PASSWD  "0990ef390f8610bc457e5432c8938fa4662534aa5482546a041b9e0d456a6b79"
#define BROKER_ASDDRESS "iot-06z00fggb93na0b.mqtt.iothub.aliyuncs.com"
#define SUB_TOPIC "/sys/k1amgRdBbwz/mqtt_stm32/thing/service/property/set"
#define PUB_TOPIC        "/sys/k1amgRdBbwz/mqtt_stm32/thing/event/property/post"
//#define JSON_FORMAT "{\\\"method\\\":\\\"thing.event.property.post\\\",\\\"params\\\":{\\\"long\\\":\\\"%s\\\"},\\\"version\\\":\\\"1.0.0\\\"}"
//#define JSON_FORMAT "{\\\"id\\\":\\\"%d\\\",\\\"version\\\":\\\"1.0\\\",\\\"params\\\":{\\\"long\\\":\\\"%s\\\"},\\\"method\\\":\\\"thing.event.property.post\\\"}"
//#define JSON_FORMAT "{\\\"params\\\":{\\\"long\\\":\\\"%s\\\"},\\\"version\\\":\\\"1.0.0\\\"}"
#define JSON_FORMAT      "{\\\"params\\\":{\\\"Longlatitude\\\":\\\"%s\\\"}\\,\\\"version\\\":\\\"1.0.0\\\"}"
//#define JSON_FORMAT "{\"params\":{\"temp\":\"%d\"},\"version\":\"1.0.0\"}"
//#define JSON_FORMAT      "{\\\"params\\\":{\\\"temp\\\":%d\\,\\\"humi\\\":%d\\}\\,\\\"version\\\":\\\"1.0.0\\\"}"
//#define JSON_FORMAT      "{\\\"params\\\":{\\\"Longlatitude\\\":%s\\,\\\"humi\\\":%d\\}\\,\\\"version\\\":\\\"1.0.0\\\"}"
/*
*************************************
�궨��
*************************************
*/
/*
*************************************
��������
*************************************
*/
/*
*************************************
��������
*************************************
*/
unsigned char receive_buf[512];	  //����2���ջ�������
unsigned char receive_start = 0;	//����2���տ�ʼ��־λ
uint16_t receive_count = 0;	      //����2�������ݼ�����
uint16_t receive_finish = 0;	    //����2���ս�����־λ
uint16_t counter = 0; //��������
//uint8_t *atk_get_frame;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/**
  * @brief          esp8266��������
  * @param[in]      none
  * @retval         ����0�������ݳɹ�,����1��������ʧ��
  */
char* Lora_GetMessage(void)	
{		
	static char atk_get_frame[256]={0};
	char*p=(char*)atk_mw1278d_uart_rx_get_frame();
	
	if(p != NULL)
	{
		memcpy(atk_get_frame, p, sizeof(atk_get_frame));
		printf("p=%s\r\n",p);
		p = NULL;
	}
	return atk_get_frame;

}























