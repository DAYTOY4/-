/**
 ****************************************************************************************************
 * @file        main.c
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2024-01-28
 * @brief       ATK-MW1278Dģ�����ʵ��
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 *
 * ʵ��ƽ̨:����ԭ�� STM32F103������
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/delay/delay.h"
#include "./SYSTEM/usart/usart.h"
#include "./BSP/LED/led.h"
#include "./BSP/KEY/key.h"
#include "./BSP/LCD/lcd.h"
#include "demo.h"
#include "stm32f103xb.h"
//#include "./BSP/OLED/OLED_Font.h"
#include "./BSP/OLED/OLED.h"
#include "./BSP/esp8266/esp8266.h"
#include "./BSP/ATK_MW1278D/atk_mw1278d_uart.h"

/**
 * @brief       ��ʾʵ����Ϣ
 * @param       ��
 * @retval      ��
 */
void show_mesg(void)
{
    /* LCD��ʾʵ����Ϣ */
//    lcd_show_string(10, 10, 220, 32, 32, "STM32", RED);
//    lcd_show_string(10, 47, 220, 24, 24, "ATK-MW1278D", RED);
//    lcd_show_string(10, 76, 220, 16, 16, "ATOM@ALIENTEK", RED);
//    lcd_show_string(10, 97, 220, 16, 16, "KEY0: Send", BLUE);
    
    /* �������ʵ����Ϣ */
    printf("\n");
    printf("********************************\r\n");
    printf("STM32\r\n");
    printf("ATK-MW1278D\r\n");
    printf("ATOM@ALIENTEK\r\n");
    printf("KEY0: Send\r\n");
    printf("********************************\r\n");
    printf("\r\n");
}

	void RedLineGPIO_Init(void)
	{
		GPIO_InitTypeDef GPIO_InitStruct = {0};
		__HAL_RCC_GPIOA_CLK_ENABLE();
		GPIO_InitStruct.Pin = GPIO_PIN_7;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; 
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET); 
	}

int main(void)
{
	char* Lora_Data;
	uint8_t *buf;
    HAL_Init();                         /* ��ʼ��HAL�� */
    sys_stm32_clock_init(RCC_PLL_MUL9); /* ����ʱ��, 72Mhz */
    delay_init(72);                     /* ��ʱ��ʼ�� */
    usart_init(115200);                 /* ���ڳ�ʼ��Ϊ115200 */
	OLED_Init();
	   printf("\n");
    printf("********************************\r\n");
    printf("STM32\r\n");
    printf("ATK-MO1218\r\n");
    printf("ATOM@ALIENTEK\r\n");
    printf("********************************\r\n");
    printf("\r\n");
    show_mesg();                        /* ��ʾʵ����Ϣ */
    demo_run(); 
	RedLineGPIO_Init();	/* ����ʾ������ */
	//esp8266_init();
	while(1)
	{
//			Lora_Data=Lora_GetMessage();
//			HAL_Delay(300);
//		    if(*Lora_Data=='0')
//			{
//				printf("0\r\n");	
//			}
//			else if(*Lora_Data=='1')
//			{
//				printf("1\r\n",Lora_Data);
//			}
//			else
//			{
//				printf("None\r\n");
//			}
		buf = atk_mw1278d_uart_rx_get_frame();
        if (buf != NULL)
        {

            printf("%s\r\n", buf);
			if(*buf=='1')
			{
				printf("over over\r\n");
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,GPIO_PIN_SET);
				HAL_Delay(500);
			}
			else
			{
				printf("not yet!!!\r\n");
				HAL_Delay(500);
			}
            atk_mw1278d_uart_rx_restart();
        }
		else
		{
			printf("Nothing!!!\r\n");
			HAL_Delay(500);
		}
		
	}
}
