#include <stdio.h>

#include <unistd.h>

#include "ohos_init.h"
#include "cmsis_os2.h"
#include "wifiiot_gpio.h"
#include "wifiiot_gpio_ex.h"
#include "wifiiot_errno.h"
#include "wifiiot_adc.h"
#include "GP2Y.h"

static float dustVal = 0;
static float vlt = 0;



void GP2Y_init(){
    //设置GPIO_10的复用功能为普通GPIO LED
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_10, WIFI_IOT_IO_FUNC_GPIO_10_GPIO);
    //设置GPIO_10为输出模式
    GpioSetDir(WIFI_IOT_GPIO_IDX_10, WIFI_IOT_GPIO_DIR_OUT);

    //设置GPIO_12的复用功能为普通GPIO
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_IO_FUNC_GPIO_12_GPIO);

    //设置GPIO_12为输出模式
    GpioSetDir(WIFI_IOT_GPIO_IDX_12, WIFI_IOT_GPIO_DIR_IN);



}

float GetGP2Y_Voltage(void)//
{
    unsigned int ret;
    unsigned short data;

    ret = AdcRead(WIFI_IOT_ADC_CHANNEL_0, &data, WIFI_IOT_ADC_EQU_MODEL_8, WIFI_IOT_ADC_CUR_BAIS_DEFAULT, 0xff);//

    if (ret != WIFI_IOT_SUCCESS)
    {
        printf("ADC Read Fail\n");
    }

    return (float)data* 1.8 * 4 / 4096.0;
}

float ReadGP2Yval(void){
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_10, WIFI_IOT_IO_PULL_DOWN); 
    usleep(280);
    vlt = GetGP2Y_Voltage();//读取电压值
    usleep(40);
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_10, WIFI_IOT_IO_PULL_UP); 
    usleep(9680);

    usleep(1000000);
    // if (dustVal > 36.455)

    dustVal = (5*vlt-3)/29*1000;
   // printf("vlt:%.3fV\n",(float)vlt * 1.8 * 4 / 4096.0);

    if (dustVal < 0) {
        dustVal = 0.00;
    }

    return (dustVal/2)*1000;//*1000转换为整数 

}

/* 
PM2.5 浓度均值（μg/m3）	空气质量 AQI	空气质量级别	空气质量指数类别     
0-35	                    0-50	        一级	        优
35-75	                    51-100	        二级	        良
75-115	                    101-150	        三级	        轻度污染
115-150                    	151-200	        四级	        中度污染
150-250	                    201-300	        五级	        重度污染
250-500	                    ≥300	        六级	        严重污染 */
