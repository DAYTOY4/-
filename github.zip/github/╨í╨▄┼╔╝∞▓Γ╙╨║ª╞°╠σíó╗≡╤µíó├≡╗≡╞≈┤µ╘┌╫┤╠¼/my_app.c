#include <stdio.h>

#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "ohos_init.h"
#include "cmsis_os2.h"
#include "wifiiot_pwm.h"
#include "wifiiot_gpio.h"
#include "wifiiot_gpio_ex.h"
#include "wifiiot_errno.h"
#include "wifiiot_adc.h"
#include "wifiiot_uart.h"

#include "fire.h"
#include "DHT11.h"
#include "GP2Y.h"


#include "oc_mqtt.h"
#include "wifi_connect.h"
#include "lwip/sockets.h"
//#include "E53_IA1.h"

#include <time.h>


#define my_app_TASK_STACK_SIZE 1024*8
#define my_app_TASK_PRIO 22

#define UART_TASK_STACK_SIZE 1024 * 8
#define UART_TASK_PRIO 24
#define UART_BUFF_SIZE 1000
static const char *data0 = "FAL";
static const char *data1 = "ON";



#define MSGQUEUE_OBJECTS 16 // number of Message Queue Objects

typedef struct
{ // object data type
    char *Buf;
    uint8_t Idx;
} MSGQUEUE_OBJ_t;

MSGQUEUE_OBJ_t msg;
osMessageQueueId_t mid_MsgQueue; // message queue id

#define CLIENT_ID "6857bf8e32771f177b44a76e_123456_0_1_2025062407"
#define USERNAME "6857bf8e32771f177b44a76e_123456"
#define PASSWORD "fbd442b90e88a18509b1fd2a5f7142821c76fa3fe75eb2bf86f0e2b6d5a76e84"

typedef enum
{
    en_msg_cmd = 0,
    en_msg_report,
} en_msg_type_t;

typedef struct
{
    char *request_id;
    char *payload;
} cmd_t;

typedef struct
{
    int ver;
    int temp;
    int hum;
    int hyVal;
    int amVal;
    int dustVal;

} report_t;

typedef struct
{
    en_msg_type_t msg_type;
    union
    {
        cmd_t cmd;
        report_t report;
    } msg;
} app_msg_t;

typedef struct
{
    int connected;
    int fire;
    int smoke;
    int hy;
    int am;
    int eleOn;
    int elline;
} app_cb_t;
static app_cb_t g_app_cb;

static void deal_report_msg(report_t *report)
{
    oc_mqtt_profile_service_t service;
    oc_mqtt_profile_kv_t temperature;
    oc_mqtt_profile_kv_t humidity;
    // oc_mqtt_profile_kv_t verify;
    oc_mqtt_profile_kv_t fire;
    oc_mqtt_profile_kv_t smoke;
    oc_mqtt_profile_kv_t hydrogen;
    oc_mqtt_profile_kv_t ammonia;

    oc_mqtt_profile_kv_t hyVal;
    oc_mqtt_profile_kv_t amVal;
    oc_mqtt_profile_kv_t dustVal;
    oc_mqtt_profile_kv_t eleBrake;//electric_brake
    oc_mqtt_profile_kv_t elLine;
    

    service.event_time = NULL;
    service.service_id = "RS_car";
    service.service_property = &temperature;
    service.nxt = NULL;

    temperature.key = "Temperature";
    temperature.value = &report->temp;
    temperature.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    temperature.nxt = &humidity;

    humidity.key = "Humidity";
    humidity.value = &report->hum;
    humidity.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    humidity.nxt = &fire;

    // verify.key = "Verify";
    // verify.value = &report->ver;
    // verify.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    // verify.nxt = &fire;

    fire.key = "Fire_Warning";
    fire.value = g_app_cb.fire ? "ON" : "OFF";
    fire.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
    fire.nxt = &smoke;

    smoke.key = "Smoke_Warning";
    smoke.value = g_app_cb.smoke ? "ON" : "OFF";
    smoke.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
    smoke.nxt = &hydrogen;

    hydrogen.key = "hydrogen_warning";
    hydrogen.value = g_app_cb.hy ? "ON" : "OFF";
    hydrogen.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
    hydrogen.nxt = &ammonia;

    ammonia.key = "ammonia_warning";
    ammonia.value = g_app_cb.am ? "ON" : "OFF";
    ammonia.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
    ammonia.nxt = &eleBrake;

    eleBrake.key = "eleBrake";
    eleBrake.value = g_app_cb.eleOn ? "ON" : "OFF";
    eleBrake.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
    eleBrake.nxt = &hyVal;

    hyVal.key = "hyVal";
    hyVal.value = &report->hyVal;
    hyVal.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    hyVal.nxt = &amVal;

    amVal.key = "amVal";
    amVal.value = &report->amVal;
    amVal.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    amVal.nxt = &dustVal;

    dustVal.key = "dustVal";
    dustVal.value = &report->dustVal;
    dustVal.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    dustVal.nxt = &elLine;

    elLine.key = "elLine";
    elLine.value = g_app_cb.elline ? "ON" : "OFF";
    elLine.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
    elLine.nxt = NULL;


    oc_mqtt_profile_propertyreport(USERNAME, &service);
    return;
}

void oc_cmd_rsp_cb(uint8_t *recv_data, size_t recv_size, uint8_t **resp_data, size_t *resp_size)
{
    app_msg_t *app_msg;

    int ret = 0;
    app_msg = malloc(sizeof(app_msg_t));
    app_msg->msg_type = en_msg_cmd;
    app_msg->msg.cmd.payload = (char *)recv_data;

    printf("recv data is %.*s\n", recv_size, recv_data);
    ret = osMessageQueuePut(mid_MsgQueue, &app_msg, 0U, 0U);
    if (ret != 0)
    {
        free(recv_data);
    }
    *resp_data = NULL;
    *resp_size = 0;
}

///< COMMAND DEAL
#include <cJSON.h>
static void deal_cmd_msg(cmd_t *cmd)
{
    cJSON *obj_root;
    cJSON *obj_cmdname;
    cJSON *obj_paras;
    cJSON *obj_para;

    int cmdret = 1;
    oc_mqtt_profile_cmdresp_t cmdresp;
    obj_root = cJSON_Parse(cmd->payload);
    if (NULL == obj_root)
    {
        goto EXIT_JSONPARSE;
    }

    obj_cmdname = cJSON_GetObjectItem(obj_root, "command_name");
    if (NULL == obj_cmdname)
    {
        goto EXIT_CMDOBJ;
    }
    
    if (0 == strcmp(cJSON_GetStringValue(obj_cmdname), "sin_pec_eletric_brake"))
    {
        obj_paras = cJSON_GetObjectItem(obj_root, "Paras");
        if (NULL == obj_paras)
        {
            goto EXIT_OBJPARAS;
        }
        obj_para = cJSON_GetObjectItem(obj_paras, "eleOn");
        if (NULL == obj_para)
        {
            goto EXIT_OBJPARA;
        }
    
        if (0 == strcmp(cJSON_GetStringValue(obj_para), "ON"))
        {
            g_app_cb.eleOn = 1;
            UartWrite(WIFI_IOT_UART_IDX_1, (unsigned char *)data1, strlen(data1));
            printf(" send data:%s\n\r", data1);
            printf("electric_brake On!");
        }
        else
        {
            g_app_cb.eleOn = 0;
            UartWrite(WIFI_IOT_UART_IDX_1, (unsigned char *)data0, strlen(data0));
            printf(" send data:%s\n\r", data0);
            printf("electric_brake Off!");
        }
        cmdret = 0;     

    }

EXIT_OBJPARA:
EXIT_OBJPARAS:
EXIT_CMDOBJ:
    cJSON_Delete(obj_root);
EXIT_JSONPARSE:
    ///< do the response
    cmdresp.paras = NULL;
    cmdresp.request_id = cmd->request_id;
    cmdresp.ret_code = cmdret;
    cmdresp.ret_name =  NULL;
    (void) oc_mqtt_profile_cmdresp(NULL, &cmdresp);
    return ;
}

static int task_main_entry(void)
{
    app_msg_t *app_msg;

    uint32_t ret = WifiConnect("HONOR", "0987654321");

    device_info_init(CLIENT_ID, USERNAME, PASSWORD);
    oc_mqtt_init();
    oc_set_cmd_rsp_cb(oc_cmd_rsp_cb);

    while (1)
    {
        app_msg = NULL;
        (void)osMessageQueueGet(mid_MsgQueue, (void **)&app_msg, NULL, 0U);
        if (NULL != app_msg)
        {
            switch (app_msg->msg_type)
            {
            case en_msg_cmd:
                deal_cmd_msg(&app_msg->msg.cmd);
                break;
            case en_msg_report:
                deal_report_msg(&app_msg->msg.report);
                break;
            default:
                break;
            }
            free(app_msg);
        }
    }
    return 0;
}

    int hum;//湿度
    int tmp;//温度
    int jiaoyan; //校验

static int task_sensor_entry(void)
{
    app_msg_t *app_msg;
        //初始化GPIO
    GpioInit();

     //火焰
    float KY_voltage;
    //上拉，让GPIO_9保持高电平状态
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_9, WIFI_IOT_IO_PULL_UP);

    //烟雾
    float MQ_voltage;
    //下拉，让GPIO_4保持低电平状态
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_4, WIFI_IOT_IO_PULL_DOWN); 


            //氢气
    float MQ_8val;
    //下拉，让GPIO_7保持低电平状态
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_7, WIFI_IOT_IO_PULL_DOWN); 


        //氨气
    float MQ_135val;
    //下拉，让GPIO_11保持低电平状态
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_11, WIFI_IOT_IO_PULL_DOWN); 

/*esp电平通信*/
    //设置GPIO_2的复用功能为普通GPIO
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_2, WIFI_IOT_IO_FUNC_GPIO_2_GPIO);//esp电平通信高位

    //设置GPIO_2为输出模式
    GpioSetDir(WIFI_IOT_GPIO_IDX_2, WIFI_IOT_GPIO_DIR_OUT);
    
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_8, WIFI_IOT_IO_FUNC_GPIO_8_GPIO);//esp电平通信低位

    GpioSetDir(WIFI_IOT_GPIO_IDX_8, WIFI_IOT_GPIO_DIR_OUT);

    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 0);
    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, 0);
    /*
    00:环境数据正常
    01:出现明火
    10:环境温湿度异常
    11:有害气体泄漏
    */

    while (1)
    {    
    // WifiIotGpioDir val = {0};
    // GpioGetDir(WIFI_IOT_GPIO_IDX_8,&val);
    // WifiIotGpioValue outputval = {0};
    // GpioGetInputVal(WIFI_IOT_GPIO_IDX_8,&outputval);
    // printf("electric brake is %d\n\r",outputval);
    // usleep(10000);
        app_msg = malloc(sizeof(app_msg_t));

        // if(outputval==1){
        //     g_app_cb.elline =1;
        //     printf("liner is brake \n\r");
        // }
        // else{
        //     g_app_cb.elline =0;
        
        //     printf("liner is good \n\r");
        // }

        //DHT11ReadData(&hum,&tmp,&jiaoyan);
    
        printf(" 湿度：%d,  温度：%d ,校验：%d\n\r",hum,tmp,jiaoyan);

        float FI = GetKY_Voltage();
        float SM = GetMQ_Voltage();
        int hyVal = GetMQ_8Val();
        int amVal = GetMQ_135Val();
        int dustVal = ReadGP2Yval();

        // if(FI > 2 && SM < 3.6 && amVal < 1000 && hyVal < 1000)
        // {
        //     GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 0);
        //     GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, 0);
        // }
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 0);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, 0);
         if(hum > 85 || tmp > 35)
         {
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 1);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, 0);
            usleep(5000000);
         }

        if(FI < 2)
        {
            g_app_cb.fire = 1;
         //   smoke_StatusSet(ON);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 0);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, 1);
            usleep(5000000);
            printf("Fire_Warning On!\n\r");
        }
        else
        {
            g_app_cb.fire = 0;
          //  smoke_StatusSet(OFF);
            printf("Fire_Warning Off~\n\r");
        }

         if (SM > 3.6)
        {
            g_app_cb.smoke = 1;
         //   smoke_StatusSet(ON);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 1);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, 1);
            usleep(5000000);
            printf("Smoke_Warning On!\n\r");
        }
        else
        {
            g_app_cb.smoke = 0;
          //  smoke_StatusSet(OFF);
          
            printf("Smoke_Warning Off~\n\r");
        }


        if (amVal > 1000)//氨气
        {
            g_app_cb.am = 1;
         //   smoke_StatusSet(ON);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 1);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, 1);
            usleep(5000000);
            printf("ammonia_warning On!\n\r");
        }
        else
        {
            g_app_cb.am = 0;
          //  smoke_StatusSet(OFF);
            printf("ammonia_warning Off~\n\r");
        }

        if (hyVal > 1000)//氢气
        {
            g_app_cb.hy = 1;
         //   smoke_StatusSet(ON);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 1);
            GpioSetOutputVal(WIFI_IOT_GPIO_IDX_8, 1);
            usleep(5000000);
            printf("hydrogen_warning On!\n\r");
        }
        else
        {
            g_app_cb.hy = 0;
          //  smoke_StatusSet(OFF);
            printf("hydrogen_warning Off~\n\r");
        }


        if (NULL != app_msg)
        {                                  //数据上报
            app_msg->msg_type = en_msg_report;
            app_msg->msg.report.hum = hum;//(int)data.Humidity;
            //app_msg->msg.report.ver = jiaoyan ;//(int)data.Lux;
            app_msg->msg.report.temp = tmp;//(int)data.Temperature;
            app_msg->msg.report.hyVal = hyVal;
            app_msg->msg.report.amVal = amVal;
            app_msg->msg.report.dustVal = dustVal;

            if (0 != osMessageQueuePut(mid_MsgQueue, &app_msg, 0U, 0U))
            {
                free(app_msg);
            }
        }
        sleep(3);
    }
    return 0;
}

static void my_appTask(void)
{

    //初始化GPIO
    GpioInit();

     //火焰
    float KY_voltage;
    //上拉，让GPIO_9保持高电平状态
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_9, WIFI_IOT_IO_PULL_UP);

    //烟雾
    float MQ_voltage;
    //下拉，让GPIO_4保持低电平状态
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_4, WIFI_IOT_IO_PULL_DOWN); 

        //氢气
    int MQ_8val;
    //下拉，让GPIO_7保持低电平状态
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_7, WIFI_IOT_IO_PULL_DOWN); 


        //氨气
    int MQ_135val;
    //下拉，让GPIO_11保持低电平状态
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_11, WIFI_IOT_IO_PULL_DOWN); 



    // //设置GPIO_2的复用功能为普通GPIO
    // IoSetFunc(WIFI_IOT_IO_NAME_GPIO_2, WIFI_IOT_IO_FUNC_GPIO_2_GPIO);

    // //设置GPIO_2为输出模式
    // GpioSetDir(WIFI_IOT_GPIO_IDX_2, WIFI_IOT_GPIO_DIR_OUT);



    GP2Y_init();
    int dustVal;

    while (1)
    {
        DHT11ReadData(&hum,&tmp,&jiaoyan);


        //设置GPIO_2输出高电平点亮LED灯
        // GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 1);
        // usleep(10000);
        // GpioSetOutputVal(WIFI_IOT_GPIO_IDX_2, 0);
        // usleep(10000);

 
         printf("===============火焰========================\r\n");
        //获取电压值
        KY_voltage = GetKY_Voltage();
        printf("KY_vlt:%.3f V\n", KY_voltage);

        printf("===============烟雾========================\r\n");
        MQ_voltage = GetMQ_Voltage();
        printf("MQ_vlt:%.3f V\n", MQ_voltage); 

        printf("===============氢气========================\r\n");
        MQ_8val = GetMQ_8Val();
        printf("MQ_8val:%d /1000 ppm\n", MQ_8val); 

        printf("===============氨气========================\r\n");
        MQ_135val = GetMQ_135Val();
        printf("MQ_135val:%d /1000 ppm\n", MQ_135val); 



      printf("===============PM2.5浓度 /1000 ======================\r\n");
      dustVal = ReadGP2Yval();
      printf("dustVal:%d /1000 μg/m3\n",dustVal);
    
        // DHT11ReadData(&hum,&tmp,&jiaoyan);
        // printf("DYI 湿度：%d,  温度：%d ,校验：%d\n\r",hum,tmp,jiaoyan);
        // printf(buf[4]);

        printf("                         \n\r");
        usleep(4000000);
    }
}



// static void F2_Pressed(char *arg)
// {
//     (void)arg;
//         UartWrite(WIFI_IOT_UART_IDX_1, (unsigned char *)data0, strlen(data0));
//         printf(" send data:%s\n\r", data0);
//         usleep(10000);
// }

static void UART_Task(void)
{
    GpioInit();


    // //初始化F2按键，设置为下降沿触发中断
    // IoSetFunc(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_IO_FUNC_GPIO_12_GPIO);

    // GpioSetDir(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_GPIO_DIR_IN);
    // IoSetPull(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_IO_PULL_UP);
    // GpioRegisterIsrFunc(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_INT_TYPE_EDGE, WIFI_IOT_GPIO_EDGE_FALL_LEVEL_LOW, F2_Pressed, NULL);

    uint8_t uart_buff[UART_BUFF_SIZE] = {0};
    uint8_t *uart_buff_ptr = uart_buff;
    uint32_t ret;

    // uint8_t firstThree[2];

    WifiIotUartAttribute uart_attr = {

        //baud_rate: 9600
        .baudRate = 115200,

        //data_bits: 8bits
        .dataBits = 8,
        .stopBits = 1,
        .parity = 0,
    };

    //Initialize uart driver
    ret = UartInit(WIFI_IOT_UART_IDX_1, &uart_attr, NULL);
    if (ret != WIFI_IOT_SUCCESS)
    {
        printf("Failed to init uart! Err code = %d\n", ret);
        return;
    }
    printf("UART Test Start\n");
    while (1)
    {


        //通过串口1接收数据
        UartRead(WIFI_IOT_UART_IDX_1, uart_buff_ptr, UART_BUFF_SIZE);

        // for (int i = 0; i < 2; i++) { //数据处理
        //     firstThree[i] = uart_buff[i];
        // }

        // if(0 < strcmp((const char *)firstThree ,data1)){

        //     printf("Uart1 read data:%s\n\r", firstThree);
        //     g_app_cb.eleOn = 1;
        //     //延时1s
        //     usleep(1000000);

        // }
        // else{
        //     g_app_cb.eleOn = 0;
        //     printf("Uart1 read data:%s\n\r", firstThree);
        //     //延时1s
        //     usleep(1000000);
        // }

        printf("Uart1 read data:%s", uart_buff_ptr);
        usleep(10000);
    }
}


static void my_appEntry(void)
{
    mid_MsgQueue = osMessageQueueNew(MSGQUEUE_OBJECTS, 10, NULL);
    if (mid_MsgQueue == NULL)
    {
        printf("Falied to create Message Queue!\n");
    }


    osThreadAttr_t attr;

    attr.name = "my_appTask";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = my_app_TASK_STACK_SIZE;
    attr.priority = my_app_TASK_PRIO;

    if (osThreadNew((osThreadFunc_t)my_appTask, NULL, &attr) == NULL)
    {
        printf("Falied to create my_appTask!\n");
    }

    attr.name = "UART_Task";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = UART_TASK_STACK_SIZE;
    attr.priority = UART_TASK_PRIO;

    if (osThreadNew((osThreadFunc_t)UART_Task, NULL, &attr) == NULL)
    {
        printf("[ADCExample] Falied to create UART_Task!\n");
    }

    attr.name = "task_main_entry";
    attr.stack_size = 10240;
    attr.priority = 24;
    if (osThreadNew((osThreadFunc_t)task_main_entry, NULL, &attr) == NULL)
    {
        printf("Falied to create task_main_entry!\n");
    }

    attr.name = "task_sensor_entry";
    attr.stack_size = 10240;
    attr.priority = 24;
    if (osThreadNew((osThreadFunc_t)task_sensor_entry, NULL, &attr) == NULL)
    {
        printf("Falied to create task_sensor_entry!\n");
    }



}

APP_FEATURE_INIT(my_appEntry);


