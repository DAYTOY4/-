#ifndef _FIRE_H
#define _FIRE_H
#include "utils_config.h"
 
float GetKY_Voltage(void);
float GetMQ_Voltage(void);
float GetMQ_135Voltage(void);
float GetMQ_8Voltage(void);
float GetMQ_135Val(void);
float GetMQ_8Val(void);

 
#endif