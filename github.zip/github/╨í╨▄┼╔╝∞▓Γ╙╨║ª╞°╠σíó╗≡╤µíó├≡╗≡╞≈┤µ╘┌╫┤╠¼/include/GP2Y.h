#ifndef _GP2Y_H
#define _GP2Y_H
#include "utils_config.h"

void GP2Y_init(void);
float GetGP2Y_Voltage(void);
float ReadGP2Yval(void);
 
#endif