#ifndef _DHT11_H
#define _DHT11_H
#include "utils_config.h"
 
#define  DHT11_OUT  PC_OUT(14)
#define  DHT11_IN   PC_IN(14)
 
int DHT11Init(void);
int DHT11ReadData(int *Humi,int *Temp,int *jiaoyan);
int DHT11RstAndCheck(void);
void delay_us(int num);
#endif